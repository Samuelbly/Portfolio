package Cookie;


import Media.*;                  // for Turtle and TurtleDisplayer
import static Media.Turtle.*;    // for Turtle speeds
import static java.lang.Math.*;  // for Math constants and functions
import static java.awt.Color.*;  // for Color constants
import java.util.Scanner;
import java.util.Random;


/** This class ...
  *
  * @author <your name>
  * 
  * @version 1.0 (<date>)                                                        */

public class Cookie {
  
  public static void main(String[] args) {
   Scanner Scan = new Scanner(System.in);
   Random Rand = new Random();
   int compScore = 0;
   int userScore = 0;
   int counter = 0;
   
   System.out.println("Hello what is your name?");
   String name = Scan.nextLine();
   
   while(counter == 0){
    int compChoice = 1 + Rand.nextInt(3); 
    
    System.out.println("Hello" + name + "Enter 1 for rock, 2 for paper, 3 for scissors");
    int playerChoice = Scan.nextInt();
    
    if (playerChoice == compChoice) {
      System.out.println("Its a tie, no points will be awarded");
      
    }
    else if(playerChoice == 1) {
      if(compChoice == 2) {
        System.out.println("Computer Selected paper");
        System.out.println("Sorry" + name + "You lost this round");
        compScore++;
        System.out.println("Computer: " + compScore);
        System.out.println(name+ ": " + userScore);
        
      } else if(compChoice == 3) {  
        System.out.println("Computer selected scissors");
        System.out.println("Congrats!" + name + "you won this round!");
        userScore++;
        System.out.println("Computer" + compScore);
        System.out.println(name +":" + userScore);
      }
    }
    else if(playerChoice == 2) {
      if(compChoice == 1){
      System.out.println("Computer selected rock");
      System.out.println("Congrats!" + name + "you won this round!");
      userScore++;
      System.out.println("Computer: " + compScore);
      System.out.println(name + ": " + userScore);
      
      } else if(compChoice == 3) {
       System.out.println("Computer selected Scissors");
       System.out.println("Sorry " + name + "you lost this round");
       compScore++;
       System.out.println("Computer:" + compScore);
       System.out.println(name + ": " + userScore); 
      }
   }
    else if(playerChoice == 3) {
      if (compChoice == 1) {
       System.out.println("Computer selected rock ");
       System.out.println("Sorry " + name + "you lost this round");
       compScore++;
       System.out.println("computer: " + compScore);
       System.out.println(name + ": " + userScore); 
       
      } else if(compChoice == 2) {
       System.out.println("computer selected paper");
        System.out.println("Congrats! " + name + " You won this round");
        userScore++;
        System.out.println("computer: " + compScore);
        System.out.println(name + ": " + userScore);
      }
      }
      if(userScore == 5){
        System.out.println("YOU WONE THE GAME! CONGRATS!");
        counter++;
      }
      if(compScore == 5) {
       System.out.println("Sorry but you have been defeated! ");
       counter++;
      }
   }
    
    
    
    
  
}
}// <className>